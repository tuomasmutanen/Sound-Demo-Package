% AN EXAMPLE MATLAB SCRIPT FOR USING DDWIENER AND SOUND 
%
% This is an EEGLAB-compatible MATLAB script that demonstrates how DDWiener
% and SOUND can be used to clean a partially noisy EEG dataset.
%
% The sample EEG dataset used in this script can be downloaded from the HeadIT
% Data Repository (http://headit.ucsd.edu/) maintained by the Swartz Center
% for Computational Neuroscience at the University of California at San 
% Diego. The used dataset corresponds to the study of Auditory Two-Choice
% Response Task with an Ignored Feature Difference, session 7, recording 1 and can be 
% downloaded from http://headit.ucsd.edu/recording_sessions/99bc255c-a238-11e2-b5e7-0050563f2612.
% In order to use the HeadIT Data Repository, the user must agree to the
% HeadIT Data Repository Terms of use and the Data use agreement.
%
% Since the sample EEG dataset is in Biosemi data format (.bdf), the BioSig
% toolbox is also needed and can be downloaded from http://biosig.sourceforge.net/download.html.
%
% Before running this script, make sure that the script and the functions 
% used in it, EEGLAB toolbox (Version 14.0.0b has been tested), BioSig
% toolbox (Version 3.1.0 has been tested), the used EEG dataset, and the 
% file containing the channel locations are located in your MATLAB path.
%
% .........................................................................
% 24 September 2017: Tuomas Mutanen, Johanna Metsomaa, Sara Liljander, and Risto Ilmoniemi. 
% Department of Neuroscience and Biomedical Engineering (NBE), School of Science, Aalto University  
% .........................................................................

%% 1. Use EEGLAB with BioSig toolbox to read in the EEG dataset and the corresponding electrode locations. 
%  Depending on your computer, this may take a moment.

disp('Shell 1 started')

clear;
close all;

% Start EEGLAB under MATLAB
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;

% Read in the EEG dataset
EEG = pop_biosig('eeg_recording_1.bdf', 'channels',[1:254]);

% Read in the channel-location file 
EEG = pop_chanedit(EEG, 'load', {'channel_locations.elp' 'filetype' 'autodetect'});

% Choose a reference channel (a recommended step for Biosemi data)
EEG = pop_reref(EEG, 49);

disp('Shell 1 ended')
%% 2. Pre-process the EEG signals with EEGLAB

disp('Shell 2 started')

% High-pass filter. 
[EEG,~,b] = pop_firws(EEG, 'fcutoff', 0.1, 'ftype', 'highpass', 'wtype', 'hamming', 'forder', 4224, 'minphase', 0);

% Extract data epochs
EEG = pop_epoch(EEG, {'200'}, [-0.1 0.5]);

% Remove baseline
EEG = pop_rmbase(EEG, [-100 0]);

disp('Shell 2 ended')
%% 3. Compute the original ERPs before DDWiener- and SOUND corrections, and visualize the resulting ERP traces in different EEG channels

disp('Shell 3 started')

% Iniate a new EEG file where the ERP will be saved
ERP_bef_clean = EEG;

% Estimate the evoked responses as the mean over trials
EEG_evo = mean(EEG.data,3);

% Re-reference to the average reference before visualization
[ERP_bef_clean.data] = ref_ave(EEG_evo);

% Plot the ERPs before cleaning as single-channel traces. The time course
% of a specific channel can be visualized by clicking on its trace,
% producing a pop-up sub-axis view. (The figure works better if you
% enlarge it to the full-screen mode)

timeAxis = linspace(-100,500,size(EEG.data,2));
InteractiveEEGPlot(timeAxis,ERP_bef_clean.data,[],ERP_bef_clean.chanlocs,[-10,10])

disp('Shell 3 ended')
%% 4. Taking noisy trials into account with DDWiener
% This shell finds the DDWiener estimates of the noise levels in each trial, 
% and visualizes the trial-specific noise estimates in all the channels
disp('Shell 4 started')

% The function <trial_noise_estimator> performs DDWiener accross the trials 
% and estimates the evoked response optimally given the trial-specific
% noise levels:

% (The data contain several channels and trials so this step may take sevaral minutes)
[EEG_evo,est_noise,tris] = trial_noise_estimator(EEG.data); 

% Make an interactive plot showing the channel-specific DDWiener estimate 
% of the noise distribution across the trials. By clicking at any specific 
% point in the color map with the data cursor, you can visualize the ERP 
% in that specific trial vs. other trials, at the specified channel. 
% You can end the interactive view by pressing any key on the keyboard 
% (while having the figure active). The illustration works better in the 
% full-screen mode. After clicking once to the colormap, you can also zoom
% into the trial-channel noise map. Note that at this stage, the ERP:s have
% not been SOUND-corrected yet.

plotTriNoise(est_noise,timeAxis,EEG.data);

disp('Shell 4 ended')
%% 5. Use SOUND to clean the channel-specific noise
% This shell uses SOUND to detect the remaining noise in the ERPs.

disp('Shell 5 started')

% Build the spherical lead field, using the theoretical electrode-locations
% of the data.
[LFM_sphere] = construct_spherical_lead_field(EEG);

% Re-reference the data and the lead field to the channel with the least noise
[~, sigmas] = DDWiener(EEG_evo);
[~,bestC] = min(sigmas);
[datatmp] = ref_best(EEG_evo, bestC);
[LFM_sphere_tmp] = ref_best(LFM_sphere, bestC);



% Set the SOUND parameters:

% Set the reqularization parameter of the minimum-norm estimate when
% finding the noise-free current estimates. This can be adjusted if clear
% under- or overcorrection is observed. lambda_value = 0.1 was used in the 
% original article. 
lambda_value = 0.1; 

% Set the number of iterations when estimating the channel-specific noise
% estimates. Iter = 5 was found to be sufficient in the datasets studied in
% the original article. 
iter = 5;

% Run the SOUND algorithm:

% (The data contain several channels so SOUND may take a few 
% minutes.)
chans = setdiff(1:size(EEG_evo,1),bestC);
[corrected_data,x,sigmas,dn] = SOUND(datatmp(chans,:), LFM_sphere_tmp(chans,:), iter, lambda_value); 


% Re-reference the data and the lead field to the channel average:
[LFM_sphere_mean] = ref_ave(LFM_sphere);
ERP_cleaned = LFM_sphere_mean*x;

disp('Shell 5 ended')
%% 6. Visualize the corrected data

disp('Shell 6 started')

% Plotting the ERPs before (red color) and after (black color) performing 
% the DDWiener and SOUND corrections. The time course of a specific channel 
% can be  visualized by clicking on its trace, producing a pop-up sub-axis 
% view.
InteractiveEEGPlot(timeAxis,ERP_bef_clean.data,ERP_cleaned,ERP_bef_clean.chanlocs)

% Plot a butterfly plot with the superimposed ERPs for all the channels. The
% original ERP signals are shown in red color and the cleaned ERP signals
% in black color. The topoplots of the original and the cleaned ERP signals
% for a specific time point can be visualized by clicking on that specific
% time point, producing a pop-up view with the topoplots.
InteractiveButterflyPlot(timeAxis,ERP_bef_clean.data,ERP_cleaned,ERP_bef_clean.chanlocs)

disp('Shell 6 ended')